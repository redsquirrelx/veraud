"""Tiny sample shop package."""
